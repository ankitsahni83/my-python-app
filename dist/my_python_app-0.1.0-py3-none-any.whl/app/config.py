class Config:
    DEBUG = False
    TESTING = False
    SECRET_KEY = 'your_secret_key'